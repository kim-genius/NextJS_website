

export default function Cart() {
  return (
    <div>
        <h1>장바구니입니다</h1>
    </div>
  );
}
