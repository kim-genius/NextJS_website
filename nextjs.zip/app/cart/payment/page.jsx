

export default function payment() {
    return (
      <div>
           <h1>결제페이지입니다</h1>
      </div>
    );
  }
  