

export default function Detail() {
    return (
        <div className="text-center">
        <h2>Detail Page</h2>
      </div>
    );
  }
  