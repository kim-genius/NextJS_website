export default function NotFound(){
    return(
        <div>
        없는페이지입니다
        </div>
    )
}