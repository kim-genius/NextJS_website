'use client'
export default function Error({error,reset}){
    return(
        <div>
            에러났다
        </div>
    )
}