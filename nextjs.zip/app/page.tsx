import Link from "next/link";

export default function Home() {
  return (
    <main>
    <h1 className="mt-32 text-6xl font-bold underline text-center">nextJS website</h1>
    <h3 className="mt-28 text-4xl font-bold text-center">by Genius</h3>
    </main>
  );
}
